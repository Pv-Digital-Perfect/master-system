import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState, useRef, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import { toast } from "sonner";
import { useHomeContent } from "@/hooks/useSettings";
import { useGlobalSearch } from "@/hooks/useGlobalSearch";
import { TIERTARIF_HOME_TRUST_ITEMS } from "@/lib/tiertarifHomeContent";
import {
  Activity,
  ArrowRight,
  CheckCircle2,
  ClipboardCheck,
  ExternalLink,
  Heart,
  Loader2,
  Search,
  ShieldCheck,
} from "lucide-react";

const calculatorFields = [
  {
    label: "Hunde",
    value: "Hundekrankenversicherung Vergleich",
    helper: "OP-Schutz, Vollschutz & GOT prüfen",
    icon: Heart,
    to: "/hundekrankenversicherung-vergleich",
  },
  {
    label: "Katzen",
    value: "Katzenversicherung Vergleich",
    helper: "FORL, Zahn-OP & Wartezeiten prüfen",
    icon: Activity,
    to: "/katzenversicherung-vergleich",
  },
  {
    label: "Pferde",
    value: "Pferde OP Versicherung Vergleich",
    helper: "Kolik-OP, Klinikwahl & Standgeld prüfen",
    icon: ShieldCheck,
    to: "/pferde-op-versicherung-vergleich",
  },
] as const;

const isLegacyHeroText = (value: string | undefined, legacyNeedles: string[]) => {
  const normalized = String(value ?? "").toLowerCase();

  return !normalized || legacyNeedles.some((needle) => normalized.includes(needle.toLowerCase()));
};

export const HeroSection = () => {
  const [searchQuery, setSearchQuery] = useState("");
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);

  const navigate = useNavigate();
  const { content } = useHomeContent();
  const { data: searchResults = [], isLoading: isSearching } = useGlobalSearch(searchQuery);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsSearchFocused(false);
      }
    }

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  if (!content) return null;

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();

    if (searchQuery.trim()) {
      navigate(`/kategorien?search=${encodeURIComponent(searchQuery)}`);
      setIsSearchFocused(false);
      return;
    }

    toast.error("Bitte gib einen Suchbegriff ein.");
  };

  const heroTitle = isLegacyHeroText(content.hero?.title, [
    "Vergleiche, Rechner",
    "zentraler Vergleichs-Hub",
    "Tools",
    "Software",
  ])
    ? "Tierversicherung vergleichen"
    : content.hero?.title;

  const heroSubtitle = isLegacyHeroText(content.hero?.subtitle, [
    "zahlreiche Anbieter",
    "Tools",
    "Software",
    "Lifestyle",
    "Erfolg",
  ])
    ? "Prüfe Leistungen, Kosten, Wartezeiten und Erstattung sachlich für Hund, Katze und OP-Schutz."
    : content.hero?.subtitle;

  const badgeText = content.hero?.badge || "TierTarif Vergleichsportal";
  const searchPlaceholder = content.hero?.search_placeholder || "Hund, Katze oder OP-Versicherung suchen";
  const searchButtonLabel = content.hero?.search_label || "Vergleich starten";
  const heroDesktopImageUrl = typeof content.hero?.desktop_image_url === "string" ? content.hero.desktop_image_url.trim() : "";
  const heroMobileImageUrl = typeof content.hero?.mobile_image_url === "string" ? content.hero.mobile_image_url.trim() : "";
  const heroImageUrl = heroDesktopImageUrl || heroMobileImageUrl;
  const hasHeroImage = Boolean(heroImageUrl);

  const showDropdown = isSearchFocused && searchQuery.length >= 2;
  const heroStats = Array.isArray(content.hero?.stats) && content.hero.stats.length > 0
    ? content.hero.stats.slice(0, 3)
    : [
        { title: "Hunde", label: "Kranken- und OP-Schutz" },
        { title: "Katzen", label: "OP, Zahn und Wartezeit" },
        { title: "Pferde", label: "OP und Haftpflicht" },
      ];

  return (
    <section className={`relative overflow-hidden pt-28 md:pt-40 ${hasHeroImage ? "bg-primary" : "bg-[#F8F5EE]"}`}>
      {hasHeroImage && (
        <picture className="absolute inset-0 z-0 block">
          {heroMobileImageUrl && <source media="(max-width: 767px)" srcSet={heroMobileImageUrl} />}
          <img
            src={heroImageUrl}
            alt=""
            aria-hidden="true"
            loading="eager"
            decoding="async"
            className="h-full w-full object-cover"
          />
        </picture>
      )}

      <div className="absolute inset-0 z-[1] pointer-events-none">
        {hasHeroImage ? (
          <>
            <div className="absolute inset-0 bg-gradient-to-r from-[#FAF7F0]/96 via-[#FAF7F0]/88 to-[#FAF7F0]/68" />
            <div className="absolute inset-0 bg-gradient-to-b from-[#FAF7F0]/70 via-transparent to-white" />
          </>
        ) : (
          <div className="absolute inset-0 bg-gradient-to-br from-[#FAF7F0] via-white to-[#EEF7F3]" />
        )}
        <div className="absolute left-[-8rem] top-24 h-72 w-72 rounded-full bg-secondary/10 blur-3xl" />
        <div className="absolute right-[-10rem] top-20 h-80 w-80 rounded-full bg-primary/10 blur-3xl" />
        <div className="absolute inset-x-0 bottom-0 h-28 bg-gradient-to-t from-white to-transparent" />
      </div>

      <div className="container relative z-10 mx-auto px-4 pb-14 md:pb-20">
        <div className="grid items-center gap-10 lg:grid-cols-[1.02fr_0.98fr] lg:gap-14">
          <div className="max-w-3xl">
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-secondary/25 bg-secondary/10 px-4 py-2 text-sm font-bold text-primary shadow-sm backdrop-blur-sm">
              <span className="flex h-7 w-7 items-center justify-center rounded-full bg-secondary text-secondary-foreground">
                <ShieldCheck className="h-4 w-4" />
              </span>
              {badgeText}
            </div>

            <h1 className="max-w-3xl text-4xl font-display font-extrabold leading-[1.04] tracking-tight text-primary md:text-6xl lg:text-7xl">
              {heroTitle}
            </h1>

            <p className="mt-6 max-w-2xl text-lg font-medium leading-relaxed text-muted-foreground md:text-xl">
              {heroSubtitle}
            </p>

            <div ref={searchRef} className="relative z-30 mt-8 max-w-2xl">
              <form
                onSubmit={handleSearch}
                className="group tt-glass-card relative flex flex-col gap-3 rounded-[1.7rem] border border-secondary/20 p-2 transition-all duration-300 focus-within:border-secondary/50 focus-within:shadow-2xl focus-within:shadow-secondary/20 sm:flex-row"
              >
                <div className="flex h-14 flex-1 items-center px-4">
                  <Search className="mr-3 h-5 w-5 shrink-0 text-secondary" />
                  <Input
                    type="text"
                    placeholder={searchPlaceholder}
                    className="h-full border-none bg-transparent p-0 text-base font-semibold text-foreground placeholder:text-muted-foreground focus-visible:ring-0 focus-visible:ring-offset-0 md:text-lg"
                    value={searchQuery}
                    onChange={(e) => {
                      setSearchQuery(e.target.value);
                      setIsSearchFocused(true);
                    }}
                    onFocus={() => setIsSearchFocused(true)}
                  />
                  {isSearching && <Loader2 className="ml-2 h-5 w-5 animate-spin text-primary" />}
                </div>

                <Button
                  type="submit"
                  size="lg"
                  className="tt-coral-shine h-14 rounded-2xl px-7 text-base font-extrabold sm:rounded-[1.25rem]"
                >
                  {searchButtonLabel}
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </form>

              {showDropdown && (
                <div className="absolute left-0 right-0 top-full z-[100] mt-4 overflow-hidden rounded-2xl border border-border bg-white text-left shadow-2xl animate-in fade-in slide-in-from-top-4 duration-200">
                  {searchResults.length > 0 ? (
                    <div className="max-h-[60vh] overflow-y-auto p-2">
                      {searchResults.map((result) => (
                        <Link
                          key={result.id}
                          to={result.url}
                          onClick={() => setIsSearchFocused(false)}
                          className="group flex items-center gap-4 rounded-xl p-3 transition-all hover:bg-muted"
                        >
                          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-muted text-xl text-primary transition-colors group-hover:bg-secondary group-hover:text-secondary-foreground">
                            {result.icon || "🔍"}
                          </div>
                          <div className="min-w-0 flex-1">
                            <h4 className="truncate text-sm font-bold text-foreground transition-colors group-hover:text-secondary">
                              {result.title}
                            </h4>
                            {result.subtitle && (
                              <p className="mt-0.5 truncate text-xs text-muted-foreground">
                                {result.subtitle}
                              </p>
                            )}
                          </div>
                          <ExternalLink className="h-4 w-4 shrink-0 text-muted-foreground group-hover:text-secondary" />
                        </Link>
                      ))}
                    </div>
                  ) : !isSearching && searchQuery.length >= 2 ? (
                    <div className="p-8 text-center">
                      <p className="text-sm text-muted-foreground">
                        Keine Treffer für <span className="font-bold text-foreground">&quot;{searchQuery}&quot;</span>
                      </p>
                    </div>
                  ) : null}
                </div>
              )}
            </div>

            <div className="mt-8 grid max-w-2xl gap-3 sm:grid-cols-3">
              {heroStats.map((stat, index) => (
                <div
                  key={`${stat.title}-${stat.label}-${index}`}
                  className="rounded-2xl border border-secondary/20 bg-white/95 p-4 shadow-sm backdrop-blur-sm transition-all hover:-translate-y-0.5 hover:border-secondary/45 hover:shadow-md hover:shadow-secondary/10"
                >
                  <div className="text-sm font-extrabold text-primary">{stat.title}</div>
                  <div className="mt-1 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                    {stat.label}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="relative">
            <div className="absolute -inset-4 rounded-[2.4rem] bg-secondary/15 blur-2xl" />

            <div className="tt-glass-card relative overflow-hidden rounded-[2rem] border border-secondary/25 p-5 backdrop-blur-sm md:p-7">
              <div className="mb-6 flex items-start justify-between gap-4">
                <div>
                  <p className="text-xs font-bold uppercase tracking-[0.22em] text-primary">Tarif-Check</p>
                  <h2 className="mt-2 text-2xl font-display font-extrabold text-primary md:text-3xl">
                    Starte einen Vergleichsrechner
                  </h2>
                </div>
                <div className="flex shrink-0 flex-col items-end gap-2">
                  <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-secondary/15 text-primary ring-1 ring-secondary/20 shadow-sm">
                    <ClipboardCheck className="h-6 w-6" />
                  </div>
                  <span className="rounded-full bg-secondary/10 px-3 py-1 text-xs font-extrabold text-secondary shadow-sm">
                    kostenfrei
                  </span>
                </div>
              </div>

              <div className="mb-4 grid grid-cols-3 gap-2 rounded-2xl bg-secondary/5 p-2">
                {["1. Tier wählen", "2. Tarife prüfen", "3. Vertrag wählen"].map((step) => (
                  <div key={step} className="rounded-xl border border-secondary/25 bg-white px-3 py-2 text-center text-[11px] font-extrabold uppercase tracking-wider text-primary">
                    {step}
                  </div>
                ))}
              </div>

              <div className="space-y-3">
                {calculatorFields.map((field) => {
                  const Icon = field.icon;

                  return (
                    <Link
                      key={field.to}
                      to={field.to}
                      className="group flex w-full items-center gap-4 rounded-2xl border border-border bg-background/60 p-4 text-left transition-all hover:-translate-y-0.5 hover:border-secondary/40 hover:bg-secondary/5 hover:shadow-md hover:shadow-secondary/10"
                      aria-label={`${field.label}: ${field.value} öffnen`}
                    >
                      <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-white text-primary shadow-sm ring-1 ring-border transition-all group-hover:bg-secondary group-hover:text-secondary-foreground">
                        <Icon className="h-5 w-5" />
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="block text-xs font-bold uppercase tracking-wider text-muted-foreground">
                          {field.label}
                        </span>
                        <span className="mt-1 block text-sm font-extrabold text-foreground md:text-base">
                          {field.value}
                        </span>
                        <span className="mt-1 block text-xs font-semibold text-muted-foreground">
                          {field.helper}
                        </span>
                      </span>
                      <ArrowRight className="h-4 w-4 text-muted-foreground transition-transform group-hover:translate-x-1 group-hover:text-secondary" />
                    </Link>
                  );
                })}
              </div>

              <div className="tt-teal-shine mt-5 rounded-2xl p-5 text-primary-foreground">
                <div className="flex items-center justify-between gap-4">
                  <div>
                    <div className="text-sm font-extrabold">Nächster Schritt</div>
                    <p className="mt-1 text-sm text-primary-foreground/75">
                      Wähle dein Tier und starte den passenden Vergleich.
                    </p>
                  </div>
                  <div className="flex shrink-0 flex-wrap justify-end gap-2">
                    {calculatorFields.map((field) => (
                      <Button key={field.to} asChild size="sm" className="tt-coral-shine rounded-xl px-3 text-xs font-extrabold">
                        <Link to={field.to}>{field.label}</Link>
                      </Button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="mt-5 flex items-center gap-3 rounded-2xl border border-border bg-muted/60 p-4">
                <CheckCircle2 className="h-5 w-5 shrink-0 text-primary" />
                <p className="text-sm font-semibold leading-relaxed text-foreground">
                  Prüfe Leistungen, Kostenpunkte und Tarifdetails sachlich im Vergleich.
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-10 rounded-[1.5rem] border border-primary/10 bg-white/95 p-4 shadow-lg shadow-primary/5 backdrop-blur-sm md:mt-14">
          <div className="grid gap-3 md:grid-cols-4">
            {TIERTARIF_HOME_TRUST_ITEMS.map((item) => (
              <div key={item} className="flex items-center gap-3 rounded-2xl border border-secondary/20 bg-white/80 px-4 py-3 text-sm font-bold text-primary shadow-sm transition-all hover:-translate-y-0.5 hover:border-secondary/35 hover:bg-secondary/10">
                <CheckCircle2 className="h-4 w-4 shrink-0 text-secondary" />
                <span>{item}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};